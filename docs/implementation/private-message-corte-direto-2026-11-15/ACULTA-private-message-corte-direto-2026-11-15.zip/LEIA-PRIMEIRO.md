# ACULTA - Corte direto do Private Message

Leia `PLANO-CORTE-DIRETO.md` e `PROMPT-AGENTE-CLI.md` antes de executar.

O código em `staging/` é pré-porte, NÃO implantado ou pronto para deploy. `scripts/private_message_preflight.php` continua somente leitura e reflete terminologia antiga de handover; não é script de exclusão. `staging/manual/` inclui uninstaller e install hooks do contrib como **referência**, NÃO copie/execute diretamente. O pacote anterior foi revisado para **DESCARTE dos dados PM**, com preservação de dados compartilhados do ACULTA.
