#!/usr/bin/env python3
"""Prepare, never activate, Private Message 4.0.0-alpha5 for ACULTA Messenger.

Usage: python3 private_message_port.py --tar private_message-4.0.0-alpha5.tar.gz \
         --output var/private-message-port [--module-root web/.../aculta_messenger]

This script deliberately NEVER modifies Drupal, Composer, the database or the
active module. Transfer files from `ready` only during an approved clone cutover.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile

UPSTREAM_SHA256 = "488090c43d270ea76f42440cb800575ab5f9f830d9456dd81153236f5c308925"
TEXT_SUFFIXES = {".php", ".twig", ".yml", ".yaml", ".js", ".css", ".scss", ".md", ".txt", ".inc"}
READY_PREFIXES = ("src/", "tests/src/", "js/", "css/", "templates/", "images/")
REVIEW_PREFIXES = ("config/", "tests/")
DANGEROUS_FILES = {
    "src/Service/PrivateMessageUninstaller.php",
    "src/Service/PrivateMessageUninstallerInterface.php",
    "src/Form/AdminUninstallForm.php",
    "src/Drush/Commands/PrivateMessageCommands.php",
}
MERGE_FILES = {
    "private_message.module", "private_message.install", "private_message.theme.inc",
    "private_message.tokens.inc", "private_message.routing.yml", "private_message.services.yml",
    "private_message.permissions.yml", "private_message.libraries.yml",
    "private_message.links.menu.yml", "private_message.links.action.yml",
    "private_message.links.task.yml", "private_message.links.contextual.yml",
    "private_message.post_update.php", "private_message.views.inc",
    "private_message.api.php", "private_message.info.yml",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def classify(path: str) -> str:
    if path.startswith("modules/private_message_notify/"):
        return "excluded_optional"
    if path in MERGE_FILES or path in DANGEROUS_FILES or path.startswith("config/"):
        return "merge_manual"
    if path.startswith(READY_PREFIXES) or path.startswith("tests/src/"):
        return "ready_not_active"
    return "reference_only"


def transform(path: str, content: bytes) -> tuple[bytes, int]:
    """Change PHP namespaces/class references only; do NOT rename persistent IDs."""
    if Path(path).suffix not in TEXT_SUFFIXES:
        return content, 0
    try:
        txt = content.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"Unexpected non-UTF8 upstream text: {path}") from exc
    replacements = (
        ("Drupal\\Tests\\private_message\\", "Drupal\\Tests\\aculta_messenger\\"),
        ("Drupal\\private_message\\", "Drupal\\aculta_messenger\\"),
    )
    count = 0
    for old, new in replacements:
        n = txt.count(old)
        if n:
            txt = txt.replace(old, new)
            count += n
    return txt.encode("utf-8"), count


def run(tarball: Path, output: Path, module_root: Path | None) -> dict:
    if not tarball.is_file():
        raise ValueError(f"Tarball not found: {tarball}")
    digest = sha256(tarball.read_bytes())
    if digest != UPSTREAM_SHA256:
        raise ValueError(f"Refusing different upstream tarball: SHA256 {digest}")
    if output.exists() and any(output.iterdir()):
        raise ValueError(f"Output is not empty: {output}")

    manifest: dict = {
        "source": "private_message-4.0.0-alpha5.tar.gz",
        "upstream_sha256": digest,
        "module": "aculta_messenger",
        "status": "STAGING ONLY - DO NOT DEPLOY OR ENABLE",
        "items": [], "collisions": [], "namespace_edits": 0,
        "cautions": [
            "Ready source cannot be activated while private_message is installed: duplicate entity types.",
            "Merge assets, services, routes, hooks, dependencies and config schemas manually.",
            "History table, installed entity schema/provider and field ownership require clone migration.",
            "Never uninstall private_message until verified migration and full recoverable backup.",
            "Do not activate private_message_notify or its message-body mail template.",
            "Upstream JS assets must be audited for the ACULTA no-jQuery UI policy.",
            "Tests from upstream need adjustments and do not replace ACULTA integration tests.",
        ],
    }
    staged: list[tuple[Path, bytes]] = []
    with tarfile.open(tarball, mode="r:gz") as archive:
        for member in archive.getmembers():
            if not member.isfile():
                if member.issym() or member.islnk() or member.isdev():
                    raise ValueError(f"Refusing unsafe tar member: {member.name}")
                continue
            raw = PurePosixPath(member.name)
            if raw.is_absolute() or ".." in raw.parts or not raw.parts or raw.parts[0] != "private_message":
                raise ValueError(f"Refusing unsafe tar path: {member.name}")
            relative = PurePosixPath(*raw.parts[1:]).as_posix()
            if not relative or relative == ".":
                continue
            file_obj = archive.extractfile(member)
            if file_obj is None:
                raise ValueError(f"Cannot read member: {member.name}")
            original = file_obj.read()
            category = classify(relative)
            if category == "excluded_optional":
                manifest["items"].append({"path": relative, "classification": category, "sha256": sha256(original)})
                continue
            content, edits = transform(relative, original) if category == "ready_not_active" else (original, 0)
            manifest["namespace_edits"] += edits
            destination = Path("ready" if category == "ready_not_active" else "manual" if category == "merge_manual" else "reference") / relative
            if category == "ready_not_active" and module_root and (module_root / relative).exists():
                manifest["collisions"].append(relative)
            staged.append((destination, content))
            manifest["items"].append({
                "path": relative, "classification": category, "sha256": sha256(original),
                "staged_sha256": sha256(content), "namespace_edits": edits,
            })

    if not any(item["path"] == "LICENSE.txt" for item in manifest["items"]):
        raise ValueError("Missing upstream LICENSE.txt")
    for destination, content in staged:
        target = output / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    (output / "PORT-MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output / "README.md").write_text(
        "# Private Message 4.0.0-alpha5 - ACULTA staging\n\n"
        "**INACTIVE SOURCE PREPARATION.** These are source copies from the verified upstream package, not an activated Drupal integration.\n"
        "The `ready/` tree contains renamed PHP namespaces for integration into `aculta_messenger`. "
        "The `manual/` tree requires explicit merging and changes to install/config/route/hook ownership. "
        "Do not move these files into the live module before clone migration and compatibility tests. "
        "Inspect `PORT-MANIFEST.json` for exact hashes, namespace changes and collisions.\n",
        encoding="utf-8",
    )
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tar", required=True, type=Path, help="Exact upstream tar.gz attachment")
    parser.add_argument("--output", required=True, type=Path, help="New empty staging directory")
    parser.add_argument("--module-root", type=Path, help="Optional checkout aculta_messenger directory for collision checks")
    args = parser.parse_args()
    try:
        result = run(args.tar, args.output, args.module_root)
    except (OSError, ValueError, tarfile.TarError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    totals: dict[str, int] = {}
    for item in result["items"]:
        key = item["classification"]
        totals[key] = totals.get(key, 0) + 1
    print(json.dumps({"source_sha256": result["upstream_sha256"], "counts": totals,
                      "namespace_edits": result["namespace_edits"], "collisions": result["collisions"],
                      "output": str(args.output)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
