# Private Message 4.0.0-alpha5 - ACULTA staging

**INACTIVE SOURCE PREPARATION.** These are source copies from the verified upstream package, not an activated Drupal integration.
The `ready/` tree contains renamed PHP namespaces for integration into `aculta_messenger`. The `manual/` tree requires explicit merging and changes to install/config/route/hook ownership. Do not move these files into the live module before clone migration and compatibility tests. Inspect `PORT-MANIFEST.json` for exact hashes, namespace changes and collisions.
