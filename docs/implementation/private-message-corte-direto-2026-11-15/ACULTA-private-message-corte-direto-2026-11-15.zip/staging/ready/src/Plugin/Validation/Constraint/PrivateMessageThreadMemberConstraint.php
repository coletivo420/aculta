<?php

declare(strict_types=1);

namespace Drupal\aculta_messenger\Plugin\Validation\Constraint;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Validation\Attribute\Constraint;
use Symfony\Component\Validator\Constraint as SymfonyConstraint;

/**
 * Checks that members of the thread have permission to use private messages.
 */
#[Constraint(
  id: 'private_message_thread_member',
  label: new TranslatableMarkup('Private Message Thread Member', [], ['context' => 'Validation']),
)]
class PrivateMessageThreadMemberConstraint extends SymfonyConstraint {

  /**
   * Constraint violation error.
   *
   * The message that is shown if the user does not have permission to use the
   * private message system. We give a user not found error rather than a
   * permissions error, as revealing a permissions error would allow users to
   * discover users on the site who are not part of the private message system.
   *
   * @var string
   */
  public string $userPrivateMessagePermissionError = 'User %user not found';

}
