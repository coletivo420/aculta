<?php

declare(strict_types=1);

namespace Drupal\aculta_messenger\Service;

use Drupal\Core\Entity\Display\EntityViewDisplayInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\aculta_messenger\Entity\PrivateMessageInterface;
use Drupal\aculta_messenger\Entity\PrivateMessageThreadInterface;
use Drupal\user\UserInterface;

/**
 * The interface for the private message service.
 *
 * @todo This service refactoring is postponed to #3489224. To be implemented:
 *   - Replacement of direct calls to database with entity API calls and
 *     removing the $database class property
 *   - Strict typing with respect to BC.
 * @see https://www.drupal.org/project/private_message/issues/3489224
 */
interface PrivateMessageServiceInterface {

  /**
   * Retrieves the private message thread for the given members.
   *
   * If no thread exists, one will be created.
   *
   * @param \Drupal\user\UserInterface[] $members
   *   List of users for whom the private message thread should be retrieved.
   *
   * @return \Drupal\aculta_messenger\Entity\PrivateMessageThreadInterface
   *   A private message thread that contains all members in the thread.
   */
  public function getThreadForMembers(array $members): PrivateMessageThreadInterface;

  /**
   * Returns the most recently updated thread for the given user.
   *
   * @param \Drupal\user\UserInterface $user
   *   The user whose most recently updated thread should be retrieved.
   *
   * @return \Drupal\aculta_messenger\Entity\PrivateMessageThreadInterface|false
   *   The most recently updated thread for the given user or FALSE.
   */
  public function getFirstThreadForUser(UserInterface $user): PrivateMessageThreadInterface|false;

  /**
   * Retrieves private message threads for a given user.
   *
   * @param int $count
   *   The number of threads to retrieve.
   * @param int|null $timestamp
   *   Only threads with an earlier timestamp should be returned.
   *
   * @return array{threads: array<int, PrivateMessageThreadInterface>, next_exists: bool}
   *   An array with two keys:
   *   - threads: Array of private message threads keyed by their ID.
   *   - next_exists: Whether more threads exist after the last one.
   */
  public function getThreadsForUser(int $count, /* ?int */$timestamp = NULL): array;

  /**
   * Retrieves the number of threads a user has.
   *
   * @return int
   *   The number of threads a user has.
   */
  public function getCountThreadsForUser(): int;

  /**
   * Retrieves a users private messages created after the given ID.
   *
   * @param int $threadId
   *   The ID of the thread from which messages should be retrieved.
   * @param int $messageId
   *   The ID after which messages should be retrieved.
   *
   * @return array
   *   An array containing any new messages that the user has permission to view
   */
  public function getNewMessages($threadId, $messageId);

  /**
   * Retrieve old messages for a user that were created before the given ID.
   *
   * @param int $threadId
   *   The ID of the thread from which messages should be retrieved.
   * @param int $messageId
   *   The ID before which messages should be retrieved.
   *
   * @return array
   *   An array containing the following to keys:
   *   - messages: an array of \Drupal\aculta_messenger\Entity\PrivateMessage
   *   - next_exists: a boolean indicating whether or not any messages appear
   *     in the thread before the first message returned
   */
  public function getPreviousMessages($threadId, $messageId);

  /**
   * Retrieve inbox information for the current user.
   *
   * If $existingThreadIds is provided it means that the inbox already has
   * threads in it. Any threads that have changed since the provided last update
   * time, as well as any new threads that have been updated since the oldest
   * provided updated time, will be returned. If $existingThreadIds is not
   * provided it means the inbox is empty, so a maximum of $count number of
   * threads is instead returned.
   *
   * @param array $existingThreadIds
   *   An array of private message thread last update times, keyed by thread ID.
   * @param int $count
   *   The number of threads to return if no existing thread IDs were provided.
   *
   * @return array
   *   An array containing the following keys:
   *   - thread_ids: The IDs of any threads in the inbox, in the order in which
   *     they should appear in the inbox. This array will be used to (re) order
   *     inbox items
   *   - new_threads: An array of
   *     \Drupal\aculta_messenger\Entity\PrivateMessageThread objects for any
   *     threads that either don't exist in the DOM at the time of the request,
   *     or do exist but have been updated.
   */
  public function getUpdatedInboxThreads(array $existingThreadIds, $count = FALSE);

  /**
   * Get the current user's unread threads count.
   *
   * @return int
   *   The number of updated threads
   */
  public function getUnreadThreadCount();

  /**
   * Get the current user's unread messages count.
   *
   * @return int
   *   The number of updated threads
   */
  public function getUnreadMessageCount();

  /**
   * Marks a timestamp at which all threads are considered read.
   */
  public function updateLastCheckTime();

  /**
   * Updates the last access time for the current user on the given thread.
   *
   * @param \Drupal\aculta_messenger\Entity\PrivateMessageThreadInterface $thread
   *   The thread whose access time should be updated.
   */
  public function updateThreadAccessTime(PrivateMessageThreadInterface $thread);

  /**
   * Load the thread that a private message belongs to.
   *
   * @param \Drupal\aculta_messenger\Entity\PrivateMessageInterface $privateMessage
   *   The private message for which the thread it belongs to should be
   *   returned.
   *
   * @return \Drupal\aculta_messenger\Entity\PrivateMessageThread
   *   The private message thread to which the private message belongs
   */
  public function getThreadFromMessage(PrivateMessageInterface $privateMessage);

  /**
   * Add a link to send a private message to the owner of the given entity.
   *
   * @param array $build
   *   A render array representing the given entity. Chances should be made to
   *   this render array.
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity being rendered.
   * @param \Drupal\Core\Entity\Display\EntityViewDisplayInterface $display
   *   The display being used to render the entity.
   * @param string $view_mode
   *   The view mode being used to render the entity.
   */
  public function createRenderablePrivateMessageThreadLink(array &$build, EntityInterface $entity, EntityViewDisplayInterface $display, $view_mode);

  /**
   * Retrieve the IDs of all threads in the system.
   *
   * @return array
   *   An array of thread IDs for threads in the system.
   */
  public function getThreadIds();

  /**
   * Get the current user's unread message count by thread id.
   *
   * Retrieves the number of the current user's messages that have been updated
   * since user last thread access.
   *
   * @param int $uid
   *   The user ID of the user whose count should be retrieved.
   * @param int $thread_id
   *   The thread ID which messages should be checked.
   *
   * @return int
   *   The number of threads updated since the given timestamp
   */
  public function getThreadUnreadMessageCount($uid, $thread_id);

}
